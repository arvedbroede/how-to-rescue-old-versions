document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.querySelector('.search-input');
    const searchButton = document.querySelector('.search-button');
    const searchResultsContainer = document.querySelector('.search-results');
  
    const pages = [
        { title: 'Zeckenbiss', url: 'erste-hilfe-anleitungen/zeckenbiss_und_lyme_borreliose.html', content: 'Zecke, Biss, Floh, Haut, Borreliose' },
        { title: 'Allergische Reaktion', url: 'erste-hilfe-anleitungen/allergische_reaktion.html', content: 'Anaphylaxie, Atemnot, Hautausschlag, Schwellung, Juckreiz, Nesselsucht, Allergiesymptome, Allergen, Schock, Quaddeln, Adrenalin, Epinephrin' },
        { title: 'Startseite', url: 'index.html', content: 'Home, HowToRescue, Main, Startseite!' },
        { title: 'Über uns', url: 'über-uns.html', content: 'Über Uns, About, Impressum' },
        { title: 'Notruf', url: 'emergency_numbers.html', content: 'Notruf, Hilfe, Telefon, Nummer, Feuerwehr, Rettungsdienst, Krangenwagen, Polizei, Ärztlicher Bereitschaftsdienst, Arzt' },
        { title: 'Notrufnummern', url: 'emergency_numbers.html', content: 'Kontakt, Hilfe, E-Mail, Telefon, Nummer' },
        { title: 'Impressum', url: 'impressum.html', content: 'Impressum' },
        { title: 'Bewusstlosigkeit', url: 'erste-hilfe-anleitungen/bewusstlosigkeit.html', content: 'Bewegungslos, Reanimation, Nicht Ansprechbar' },
        { title: 'Epileptischer Anfall', url: 'erste-hilfe-anleitungen/epileptischer_anfall.html', content: 'Krampfanfall, Epilepsie, Zappeln' },
        { title: 'Erste Hilfe', url: 'erste-hilfe-anleitungen/erste_hilfe.html', content: 'Erst Hilfe, First Aid, Helfen' },
        { title: 'Helmabnahme', url: 'erste-hilfe-anleitungen/helmabnahme.html', content: 'Helm, abnhame, abnehmen, Motorrad, Unfall, Fahrrad, Einrad, Dreirad' },
        { title: 'Herzinfarkt', url: 'erste-hilfe-anleitungen/herzinfakt_und_schlaganfall.html', content: 'Brust, Schmerz, Infakt, Infarkt, Herz, Druck, Schwer' },
        { title: 'Hitzschlag', url: 'erste-hilfe-anleitungen/hitzschlag_und_unterkuehlung.html', content: 'Sonne, Hitze, Warm, Fieber, Erbrechen, Übelkeit' },
        { title: 'Insektenstich', url: 'erste-hilfe-anleitungen/insektenstiche_und_bisse.html', content: 'Stich, biene, Wespe, Mücke, Mucke' },
        { title: 'Knochenbruch', url: 'erste-hilfe-anleitungen/knochenbruch.html', content: 'Bruch, Knochen, Fehlstellung' },
        { title: 'Kopfverletzung', url: 'erste-hilfe-anleitungen/kopfverletzung.html', content: 'Platzwunde, Kopf, Verletzung' },
        { title: 'Krampfanfall', url: 'erste-hilfe-anleitungen/krampfanfall.html', content: 'XYZ' },
        { title: 'Notruf absetzen', url: 'erste-hilfe-anleitungen/notruf_absetzen.html', content: 'XYZ' },
        { title: 'Oberbauchkompression (Erw.)', url: 'erste-hilfe-anleitungen/heimlichgriff_erwachsene.html', content: 'XYZ' },
        { title: 'Oberbauchkompression (Kind)', url: 'erste-hilfe-anleitungen/heimlichgriff_kinder.html', content: 'XYZ' },
        { title: 'Reanimation', url: 'erste-hilfe-anleitungen/herz-lungen-wiederbelebung.html', content: 'tot, Tod, Atemstillstand, Reanimation, Herz Lungen Wiederbelebung' },
        { title: 'Schlaganfall', url: 'erste-hilfe-anleitungen/herzinfakt_und_schlaganfall.html', content: 'XYZ' },
        { title: 'Schock', url: 'erste-hilfe-anleitungen/schock.html', content: 'XYZ' },
        { title: 'Schocklage', url: 'erste-hilfe-anleitungen/schocklage.html', content: 'XYZ' },
        { title: 'Stabile Seitenlage', url: 'erste-hilfe-anleitungen/stabile_seitenlage.html', content: 'XYZ' },
        { title: 'Verbrennung', url: 'erste-hilfe-anleitungen/verbrennungen_und_verbrühungen.html', content: 'XYZ' },
        { title: 'Vergiftung', url: 'erste-hilfe-anleitungen/vergiftungen.html', content: 'XYZ' },
        { title: 'Verschlucken', url: 'erste-hilfe-anleitungen/verschlucken.html', content: 'XYZ' },
        { title: 'Verstauchung', url: 'erste-hilfe-anleitungen/verstauchung.html', content: 'XYZ' },
        { title: 'Wundversorgung', url: 'erste-hilfe-anleitungen/wundversorgung.html', content: 'XYZ' },
        { title: 'Zahnunfall', url: 'erste-hilfe-anleitungen/zahnunfall.html', content: 'XYZ' },
    ];
  
    function displayResults(query) {
        searchResultsContainer.innerHTML = '';
  
        // Ergebnisse nur anzeigen, wenn mindestens 3 Zeichen eingegeben wurden
        if (query.length < 2) {
            searchResultsContainer.style.display = 'none';
            return;
        }
  
        const results = pages.filter(page =>
            page.title.toLowerCase().includes(query) ||
            page.content.toLowerCase().includes(query)
        );
  
        // Sortierung nach Genauigkeit der Übereinstimmung
        results.sort((a, b) => {
            const aTitleMatch = a.title.toLowerCase() === query;
            const bTitleMatch = b.title.toLowerCase() === query;
            const aContentMatch = a.content.toLowerCase() === query;
            const bContentMatch = b.content.toLowerCase() === query;
  
            if (aTitleMatch && !bTitleMatch) return -1;
            if (!aTitleMatch && bTitleMatch) return 1;
            if (aContentMatch && !bContentMatch) return -1;
            if (!aContentMatch && bContentMatch) return 1;
  
            return a.title.localeCompare(b.title);
        });
  
        if (results.length === 0) {
            const noResultsMessage = document.createElement('div');
            noResultsMessage.textContent = 'Keine Ergebnisse gefunden.';
            searchResultsContainer.appendChild(noResultsMessage);
        } else {
            results.forEach(result => {
                const resultItem = document.createElement('div');
                resultItem.className = 'search-result-item';
                resultItem.textContent = result.title;
                resultItem.addEventListener('click', () => {
                    window.location.href = result.url;
                });
                searchResultsContainer.appendChild(resultItem);
            });
        }
  
        searchResultsContainer.style.display = 'block';
    }
  
    searchInput.addEventListener('input', () => {
        const query = searchInput.value.trim().toLowerCase();
        displayResults(query);
    });
  
    searchButton.addEventListener('click', () => {
        const query = searchInput.value.trim().toLowerCase();
        displayResults(query);
    });
  
    searchInput.addEventListener('keypress', (event) => {
        if (event.key === 'Enter') {
            event.preventDefault();
            const query = searchInput.value.trim().toLowerCase();
            displayResults(query);
        }
    });
  });
  