function openPopup(step) {
    var popup = document.getElementById("popup");
    var title = document.getElementById("popup-title");
    var textList = document.getElementById("popup-text");

    // Leere die Liste, bevor neue Einträge hinzugefügt werden
    textList.innerHTML = '';

    // Kurzanleitungen je nach Schritt anzeigen
    if (step === 'stable-side') {
        title.innerText = "Stabile Seitenlage";
        var steps = [
            "Person in stabile Seitenlage bringen.",
            "Atmung überprüfen und beobachten.",
            "Notruf absetzen und Hilfe anfordern."
        ];
        steps.forEach(function(stepText) {
            var li = document.createElement("li");
            li.innerText = stepText;
            textList.appendChild(li);
        });
    } else if (step === 'child-breathing') {
        title.innerText = "Atemspende bei Kindern";
        var steps = [
            "Mund-zu-Mund-Beatmung durchführen.",
            "Keine Brustkompressionen bei kleinen Kindern.",
            "Notruf absetzen und Hilfe anfordern."
        ];
        steps.forEach(function(stepText) {
            var li = document.createElement("li");
            li.innerText = stepText;
            textList.appendChild(li);
        });
    } else if (step === 'adult-compressions') {
        title.innerText = "Brustkompressionen";
        var steps = [
            "Positionieren Sie Ihre Hände auf der Mitte des Brustkorbs.",
            "Komprimieren Sie mit einer Tiefe von mindestens 5 cm.",
            "100-120 Kompressionen pro Minute durchführen."
        ];
        steps.forEach(function(stepText) {
            var li = document.createElement("li");
            li.innerText = stepText;
            textList.appendChild(li);
        });
    } else if (step === 'adult-breathing') {
        title.innerText = "Atemspende bei Erwachsenen";
        var steps = [
            "Mund-zu-Mund-Beatmung durchführen.",
            "Jede Beatmung für 1 Sekunde anhalten.",
            "Überprüfen, ob die Brust sich hebt."
        ];
        steps.forEach(function(stepText) {
            var li = document.createElement("li");
            li.innerText = stepText;
            textList.appendChild(li);
        });
    } else if (step === 'adult-call') {
        title.innerText = "Notruf absetzen";
        var steps = [
            "Notrufnummer wählen (112).",
            "Angaben zur Situation machen.",
            "Bleiben Sie am Telefon, bis Hilfe eintrifft."
        ];
        steps.forEach(function(stepText) {
            var li = document.createElement("li");
            li.innerText = stepText;
            textList.appendChild(li);
        });
    }

    // Popup anzeigen
    popup.style.display = "flex";
}

function closePopup() {
    var popup = document.getElementById("popup");
    popup.style.display = "none";
}

function nextStep(step) {
    // Verstecke alle Schritte
    var steps = document.querySelectorAll('.question');
    steps.forEach(function(stepElement) {
        stepElement.classList.add('hidden');
    });

    // Zeige den nächsten Schritt
    document.getElementById(step).classList.remove('hidden');
}

function previousStep(step) {
    // Verstecke alle Schritte
    var steps = document.querySelectorAll('.question');
    steps.forEach(function(stepElement) {
        stepElement.classList.add('hidden');
    });

    // Zeige den vorherigen Schritt
    document.getElementById(step).classList.remove('hidden');
}


// TIMER //

let timerInterval;
let timeLeft = 120; // 2 Minuten in Sekunden
let breathingMessageVisible = false;

// Funktion zum Starten des Timers
function startTimer() {
    const timerElement = document.getElementById("timer");
    const messageElement = document.getElementById("breathing-check-message");
    
    // Wenn der Timer schon läuft, stoppen wir den alten Timer
    if (timerInterval) {
        clearInterval(timerInterval);
    }

    // Start des Timers
    timerInterval = setInterval(function () {
        timeLeft--;
        
        let minutes = Math.floor(timeLeft / 60);
        let seconds = timeLeft % 60;

        // Wenn der Timer abgelaufen ist und noch keine Nachricht angezeigt wurde
        if (timeLeft <= 0 && !breathingMessageVisible) {
            breathingMessageVisible = true;

            // Timer ausblenden und Nachricht anzeigen
            timerElement.classList.add("hidden");
            messageElement.classList.remove("hidden");

            // Nachricht für 15 Sekunden anzeigen
            setTimeout(function () {
                // Nachricht ausblenden und Timer wieder einblenden
                messageElement.classList.add("hidden");
                timerElement.classList.remove("hidden");

                // Setze den Timer zurück auf 2 Minuten
                timeLeft = 120;
                breathingMessageVisible = false;
            }, 15000); // Nachricht für 15 Sekunden anzeigen
        }

        // Timer anzeigen, wenn er noch läuft
        if (!breathingMessageVisible) {
            timerElement.textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
        }
    }, 1000); // Alle 1 Sekunde aktualisieren
}

// Funktion für den nächsten Schritt und Timer starten
function nextStep(step) {
    // Verstecke alle Schritte
    var steps = document.querySelectorAll('.question');
    steps.forEach(function(stepElement) {
        stepElement.classList.add('hidden');
    });

    // Zeige den nächsten Schritt
    var nextStepElement = document.getElementById(step);
    nextStepElement.classList.remove('hidden');
    
    // Wenn der nächste Schritt die stabile Seitenlage ist, starte den Timer
    if (step === 'step3a') {
        startTimer();
    }
}

// Funktion für den "KEINE Atmung"-Button, der zu Schritt 3b führt
function goToStep3b() {
    // Verstecke alle Schritte
    var steps = document.querySelectorAll('.question');
    steps.forEach(function(stepElement) {
        stepElement.classList.add('hidden');
    });

    // Zeige Schritt 3b (Handelt es sich um ein Kind?)
    var step3b = document.getElementById('step3b');
    step3b.classList.remove('hidden');
}
