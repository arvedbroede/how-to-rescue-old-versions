// Verhindert das Öffnen des Kontextmenüs (Rechtsklick)
document.addEventListener('contextmenu', function(event) {
  event.preventDefault();
  alert("Rechtsklick ist deaktiviert!");
});

// Verhindert das Drücken der F12-Taste (Entwicklertools öffnen)
document.addEventListener('keydown', function(event) {
  // Blockiert F12, Strg+Shift+I (Entwicklertools), Strg+U (Quellcode anzeigen)
  if (event.key === 'F12' || (event.ctrlKey && event.shiftKey && event.key === 'I') || (event.ctrlKey && event.key === 'u')) {
    event.preventDefault();
    alert("Diese Funktion ist deaktiviert!");
  }
});