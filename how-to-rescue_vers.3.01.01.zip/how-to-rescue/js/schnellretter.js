document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.querySelector('.search-input');
  const searchButton = document.querySelector('.search-button');
  const searchResultsContainer = document.querySelector('.search-results');

// Beispiel-Datenbank mit Seiteninformationen
  const pages = [

// Startseiten //

      { title: 'Startseite', url: 'index.html', content: 'Willkommen auf unserer Startseite!' },
      { title: 'Über uns', url: 'über-uns.html', content: 'Erfahren Sie mehr über unser Team.' },
      { title: 'Notruf', url: 'emergency_numbers.html', content: 'Unsere Dienstleistungen im Überblick.' },
      { title: 'Notrufnummern', url: 'emergency_numbers.html', content: 'Kontaktieren Sie uns über dieses Formular.' },
      { title: 'Impressum', url: 'impressum.html', content: 'XYZ' },

// Erste-Hilfe-Anleitungen //

  { title: 'Allergische Reaktion', url: 'erste-hilfe-anleitungen/allergische_reaktion.html', content: 'Anaphylaxie, Atemnot, Hautausschlag, Schwellung, Juckreiz, Nesselsucht, Allergiesymptome, Allergen, Schock, Quaddeln, Adrenalin, Epinephrin' },
  { title: 'Bewusstlosigkeit', url: 'erste-hilfe-anleitungen/bewusstlosigkeit.html', content: 'Bewegungslos, Reanimation, Nicht Ansprechbar' },
  { title: 'Epileptischer Anfall', url: 'erste-hilfe-anleitungen/epileptischer_anfall.html', content: 'XYZ' },
  { title: 'Erste Hilfe', url: 'erste-hilfe-anleitungen/erste_hilfe.html', content: 'XYZ' },
  { title: 'Helmabnahme', url: 'erste-hilfe-anleitungen/helmabnahme.html', content: 'XYZ' },
  { title: 'Herzinfarkt', url: 'erste-hilfe-anleitungen/herzinfakt_und_schlaganfall.html', content: 'XYZ' },
  { title: 'Hitzschlag', url: 'erste-hilfe-anleitungen/hitzschlag_und_unterkuehlung.html', content: 'XYZ' },
  { title: 'Insektenstich', url: 'erste-hilfe-anleitungen/insektenstiche_und_bisse.html', content: 'XYZ' },
  { title: 'Knochenbruch', url: 'erste-hilfe-anleitungen/knochenbruch.html', content: 'XYZ' },
  { title: 'Kopfverletzung', url: 'erste-hilfe-anleitungen/kopfverletzung.html', content: 'Platzwunde, Kopf, Verletzung' },
  { title: 'Krampfanfall', url: 'erste-hilfe-anleitungen/krampfanfall.html', content: 'XYZ' },
  { title: 'Notruf absetzen', url: 'erste-hilfe-anleitungen/notruf_absetzen.html', content: 'XYZ' },
  { title: 'Oberbauchkompression (Erw.)', url: 'erste-hilfe-anleitungen/heimlichgriff_erwachsene.html', content: 'XYZ' },
  { title: 'Oberbauchkompression (Kind)', url: 'erste-hilfe-anleitungen/heimlichgriff_kinder.html', content: 'XYZ' },
  { title: 'Reanimation', url: 'erste-hilfe-anleitungen/herz-lungen-wiederbelebung.html', content: 'tot, Tod, Atemstillstand, Reanimation, Herz Lungen Wiederbelebung' },
  { title: 'Schlaganfall', url: 'erste-hilfe-anleitungen/herzinfakt_und_schlaganfall.html', content: 'XYZ' },
  { title: 'Schock', url: 'erste-hilfe-anleitungen/schock.html', content: 'XYZ' },
  { title: 'Schocklage', url: 'erste-hilfe-anleitungen/schocklage.html', content: 'XYZ' },
  { title: 'Stabile Seitenlage', url: 'erste-hilfe-anleitungen/stabile_seitenlage.html', content: 'XYZ' },
  { title: 'Verbrennung', url: 'erste-hilfe-anleitungen/verbrennungen_und_verbrühungen.html', content: 'XYZ' },
  { title: 'Vergiftung', url: 'erste-hilfe-anleitungen/vergiftungen.html', content: 'XYZ' },
  { title: 'Verschlucken', url: 'erste-hilfe-anleitungen/verschlucken.html', content: 'XYZ' },
  { title: 'Verstauchung', url: 'erste-hilfe-anleitungen/verstauchung.html', content: 'XYZ' },
  { title: 'Wundversorgung', url: 'erste-hilfe-anleitungen/wundversorgung.html', content: 'XYZ' },
  { title: 'Zahnunfall', url: 'erste-hilfe-anleitungen/zahnunfall.html', content: 'XYZ' },
  { title: 'Zeckenbiss', url: 'erste-hilfe-anleitungen/zeckenbiss_und_lyme_borreliose.html', content: 'XYZ' }
  ];

  // Funktion zur Anzeige von Suchergebnissen
  function displayResults(query) {
    searchResultsContainer.innerHTML = ''; // Alte Ergebnisse löschen

    if (query === '') {
      searchResultsContainer.style.display = 'none'; // Ergebnisse ausblenden
      return;
    }

    const results = pages.filter(page =>
      page.title.toLowerCase().includes(query) ||
      page.content.toLowerCase().includes(query)
    );

    if (results.length === 0) {
      const noResultsMessage = document.createElement('div');
      noResultsMessage.textContent = 'Keine Ergebnisse gefunden.';
      searchResultsContainer.appendChild(noResultsMessage);
    } else {
      results.forEach(result => {
        const resultItem = document.createElement('div');
        resultItem.className = 'search-result-item';
        resultItem.textContent = result.title;
        resultItem.addEventListener('click', () => {
          window.location.href = result.url;
        });
        searchResultsContainer.appendChild(resultItem);
      });
    }

    searchResultsContainer.style.display = 'block'; // Ergebnisse anzeigen
  }

  // Event-Listener für die Eingabe im Suchfeld
  searchInput.addEventListener('input', () => {
    const query = searchInput.value.trim().toLowerCase();
    displayResults(query);
  });

  // Event-Listener für den Suchbutton
  searchButton.addEventListener('click', () => {
    const query = searchInput.value.trim().toLowerCase();
    displayResults(query);
  });

  // Suche bei Drücken der Enter-Taste
  searchInput.addEventListener('keypress', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault(); // Verhindert das Standardverhalten (z. B. Formularabsendung)
      const query = searchInput.value.trim().toLowerCase();
      displayResults(query);
    }
  });
});