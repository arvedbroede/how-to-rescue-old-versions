var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
  var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    // Beim Hochscrollen
    document.querySelector(".navbar").classList.remove("hidden");
  } else {
    // Beim Runterscrollen
    document.querySelector(".navbar").classList.add("hidden");
  }
  prevScrollpos = currentScrollPos;
}