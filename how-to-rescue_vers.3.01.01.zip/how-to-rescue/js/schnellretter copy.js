document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.querySelector('.search-input');
  const searchButton = document.querySelector('.search-button');
  const searchResultsContainer = document.querySelector('.search-results');

  // Beispiel-Datenbank mit Seiteninformationen
  const pages = [
      { title: 'Startseite', url: 'index.html', content: 'Willkommen auf unserer Startseite!' },
      { title: 'Über uns', url: 'über-uns.html', content: 'Erfahren Sie mehr über unser Team.' },
      { title: 'Notruf', url: 'notruf.html', content: 'Unsere Dienstleistungen im Überblick.' },
      { title: 'Notrufnummern', url: 'emergency_numbers.html', content: 'Kontaktieren Sie uns über dieses Formular.' },
      { title: 'Impressum', url: 'impressum.html', content: 'XYZ' },
      { title: 'Allergische Reaktion', url: 'allergische_reaktion.html', content: 'XYZ' },
      { title: 'Bewusstlosigkeit', url: 'bewusstlosigkeit.html', content: 'XYZ' },
      { title: 'Epileptischer Anfall', url: 'epileptischer_anfall.html', content: 'XYZ' },
      { title: 'Oberbauchkompression (Erw.)', url: 'heimlichgriff_erwachsene.html', content: 'XYZ' },
      { title: 'Oberbauchkompression (Kind)', url: 'heimlichgriff_kinder.html', content: 'XYZ' },
      { title: 'Helmabnahme', url: 'helmabnahme.html', content: 'XYZ' },
      { title: 'Reanimation', url: 'herz-lungen-wiederbelebung.html', content: 'XYZ' },
      { title: 'Herzinfarkt', url: 'herzinfakt_und_schlaganfall.html', content: 'XYZ' },
      { title: 'Schlaganfall', url: 'herzinfakt_und_schlaganfall.html', content: 'XYZ' },
      { title: 'Hitzschlag', url: 'hitzschlag_und_unterkuehlung.html', content: 'XYZ' },
      { title: 'Unterkühlung', url: 'hitzschlag_und_unterkuehlung.html', content: 'XYZ' },
      { title: 'Insektenstich', url: 'insektenstiche_und_bisse.html', content: 'XYZ' },
      { title: 'Knochenbruch', url: 'knochenbruch.html', content: 'XYZ' },
      { title: 'Verstauchung', url: 'verstauchung.html', content: 'XYZ' },
      { title: 'Kopfverletzung', url: 'kopfverletzung.html', content: 'Platzwunde, Kopf, Verletzung' },
      { title: 'Krampfanfall', url: 'krampfanfall.html', content: 'XYZ' },
      { title: 'Notruf absetzen', url: 'notruf_absetzen.html', content: 'XYZ' },
      { title: 'Schock', url: 'schock.html', content: 'XYZ' },
      { title: 'Schocklage', url: 'schocklage.html', content: 'XYZ' },
      { title: 'Stabile Seitenlage', url: 'stabile_seitenlage.html', content: 'XYZ' },
      { title: 'Verbrennung' , url: 'verbrennungen_und_verbrühungen.html', content: 'XYZ' },
      { title: 'Vergiftung', url: 'vergiftungen.html', content: 'XYZ' },
      { title: 'Verschlucken', url: 'verschlucken.html', content: 'XYZ' },
      { title: 'Wundversorgung', url: 'wundversorgung.html', content: 'XYZ' },
      { title: 'Zahnunfall', url: 'zahnunfall.html', content: 'XYZ' },
      { title: 'Zeckenbiss', url: 'zeckenbiss_und_lyme_borreliose.html', content: 'XYZ' },
      { title: 'Erste Hilfe', url: 'erste_hilfe.html', content: 'XYZ' }
  ];

  // Funktion zur Anzeige von Suchergebnissen
  function displayResults(query) {
    searchResultsContainer.innerHTML = ''; // Alte Ergebnisse löschen

    if (query === '') {
      searchResultsContainer.style.display = 'none'; // Ergebnisse ausblenden
      return;
    }

    const results = pages.filter(page =>
      page.title.toLowerCase().includes(query) ||
      page.content.toLowerCase().includes(query)
    );

    if (results.length === 0) {
      const noResultsMessage = document.createElement('div');
      noResultsMessage.textContent = 'Keine Ergebnisse gefunden.';
      searchResultsContainer.appendChild(noResultsMessage);
    } else {
      results.forEach(result => {
        const resultItem = document.createElement('div');
        resultItem.className = 'search-result-item';
        resultItem.textContent = result.title;
        resultItem.addEventListener('click', () => {
          window.location.href = result.url;
        });
        searchResultsContainer.appendChild(resultItem);
      });
    }

    searchResultsContainer.style.display = 'block'; // Ergebnisse anzeigen
  }

  // Event-Listener für die Eingabe im Suchfeld
  searchInput.addEventListener('input', () => {
    const query = searchInput.value.trim().toLowerCase();
    displayResults(query);
  });

  // Event-Listener für den Suchbutton
  searchButton.addEventListener('click', () => {
    const query = searchInput.value.trim().toLowerCase();
    displayResults(query);
  });

  // Suche bei Drücken der Enter-Taste
  searchInput.addEventListener('keypress', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault(); // Verhindert das Standardverhalten (z. B. Formularabsendung)
      const query = searchInput.value.trim().toLowerCase();
      displayResults(query);
    }
  });
});