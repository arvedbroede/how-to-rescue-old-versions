document.addEventListener("DOMContentLoaded", function() {
    const dropdown = document.querySelector(".dropdown");
    const dropdownContent = document.querySelector(".dropdown-content");

    let timeout;

    dropdown.addEventListener("mouseenter", function() {
        clearTimeout(timeout);
        dropdownContent.style.display = "block";
    });

    dropdown.addEventListener("mouseleave", function() {
        timeout = setTimeout(function() {
            dropdownContent.style.display = "none";
        }, 150); // Ändern Sie die Verzögerungszeit nach Bedarf
    });
});
